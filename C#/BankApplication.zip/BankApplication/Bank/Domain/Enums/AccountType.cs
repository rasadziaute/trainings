﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bank.Domain.Enums
{
    public enum AccountType
    {
        Savings,
        Current
    }
}
